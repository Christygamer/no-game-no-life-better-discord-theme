#<DIV ALIGN=CENTER>CC-Themes<div>
<font size="25"><b>To download the theme:</b></font>
+ Step 0: Click on the name of the desired theme
+ Step 1: Right click the raw button
+ Step 2: Click save link as 
+ Step 3: Windows-> Save to %appdata%\betterdiscord\themes\ 
+ Step 3: IOS-> Save to ~/Library/Preferences/themes 
+ Step 4: Make sure the extension is set as `.theme.css`
+ Step 5: Restart Discord (CMD+R or CTRL+R)
+ Step 6: Open Discord Settings>BetterDiscord>Themes>Enable the theme

##<DIV ALIGN=CENTER><a href="https://github.com/CurimuChizu/CC-Themes/blob/master/CC-Themes/Red.n.Black.theme.css">Red n Black</a></div>
<DIV ALIGN=CENTER><b><i>A theme based red and black with a hint of anime (Up to date as of 9/10)</i></b>
<img src="http://i.imgur.com/TdJImXS.png"/>
<img src="http://i.imgur.com/n669pit.jpg"/>
<img src="http://i.imgur.com/w1p4aNN.gif"/></div>

To change the background, just add the code below with a different link in the `Custome CSS` tab of the `BetterDiscord` settings:( Also be sure to add the `s` after `http` when you change the pic or it won't appear )
```css
.app {
    background-image: url("https://i.imgur.com/P0k3VRY.jpg") !important;
    background-size: 1500px 900px !important;
    background-repeat: no-repeat !important;
}
/* Just change the link to whatever picture, including the `s` in `https` */

.callout-backdrop {
    opacity:0.9 !important;
    background: url("https://i.imgur.com/CcntY8Y.jpg") !important;
    background-size: 1500px 900px !important;
    background-repeat: no-repeat !important;
}
```
##<DIV ALIGN=CENTER><a href="https://github.com/CurimuChizu/CC-Themes/blob/master/CC-Themes/ReZero.theme.css">ReZero The Anime</a></div>
<DIV ALIGN=CENTER><b><i>A theme based Re:Zero kara Hajimeru Isekai Seikatsu anime (Up to date as of 9/10)</i></b>
<img src="http://i.imgur.com/rthaufN.jpg"/>
<img src="http://i.imgur.com/QhU9gvh.jpg"/>
<img src="https://a.pomf.cat/fawsxb.gif"/></div>

Code for the background picture:
```css
.app {
    background-image: url("https://i.imgur.com/w7UVsOs.jpg") !important; 
    background-size: cover !important;
}
/* Just change the link to whatever picture of Emelia, Rem, or Ram including the `s` in `https` */

.callout-backdrop {
    opacity:0.9!important;
    background: url("https://i.imgur.com/eeDIMtw.jpg")!important;
    background-size: cover !important;
    background-position: center !important;
}
```
Thanks for coming~~ ^~^
